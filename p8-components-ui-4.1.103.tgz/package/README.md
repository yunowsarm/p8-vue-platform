P8-COMPONENTS-UI

<img src="https://img.shields.io/badge/version-3.2.7-blue.svg" /> <img src="https://img.shields.io/badge/build-passing-brightgreen.svg" /> <img src="https://img.shields.io/badge/license-MIT-blue.svg" />   

## 一、使用指南  

### **安装**



#### npm 安装

```js
// 公司私服安装方式
npm --registry http://192.168.0.191:8888/repository/npm-group/ install p8-components-ui
```



### 引入p8-components-ui



基于element-ui@2.15.7版本       https://element.eleme.cn/#/zh-CN

 你可以引入整个p8-components-ui，或是根据需要仅引入部分组件。我们先介绍如何引入完整的 P8-Components-ui。



####  完整引入 

 在 main.js 中写入以下内容： 

```js
import Vue from 'vue'
import api from 'p8-components-ui/dist/api'
import p8, { P8Contextmenu as Contextmenu, P8ContextmenuItem as ContextmenuItem, P8Contextmenu as directive, InfiniteScroll } from 'p8-components-ui'
import p8Config from '@/config/p8Config'
import 'p8-components-ui/dist/theme-chalk/lib/index.css'
import App from './App.vue'

Vue.use(api, p8Config)
Vue.use(p8)

new Vue({
  el: '#app',
  render: h => h(App)
});
```

 以上代码便完成了 p8-components-ui 的引入。需要注意的是，样式文件需要单独引入。 



#### 按需引入

如果你只希望引入部分组件，比如 Button，那么需要在 main.js 中写入以下内容：



```javascript

import Vue from 'vue';

import { P8Button } from 'p8-components-ui';

import App from './App.vue';



Vue.component(P8Button.name, Button);

/* 或写为

 \* Vue.use(P8Button)

 */



new Vue({

 el: '#app',

 render: h => h(App)

});

```



#### 全局配置

在引入 p8-components-ui 时，可以传入一个全局配置对象。该对象目前支持 `size` 与 `zIndex` 字段。`size` 用于改变组件的默认尺寸，`zIndex` 设置弹框的初始 z-index（默认值：2000）。按照引入 p8-components-ui 的方式，具体操作如下：



完整引入 p8-components-ui：



```js

import Vue from 'vue';

import p8 from 'p8-components-ui';

Vue.use(p8, { size: 'small', zIndex: 3000 });

```



按需引入 p8-components-ui：



```js

import Vue from 'vue';

import { P8Button } from 'p8-components-ui';

Vue.prototype.$ELEMENT = { size: 'small', zIndex: 3000 };

Vue.use(P8Button);

```



按照以上设置，项目中所有拥有 `size` 属性的组件的默认尺寸均为 'small'，弹框的初始 z-index 为 3000。



#### 开始使用



至此，一个基于 Vue 和 p8-components-ui的开发环境已经搭建完毕，现在就可以编写代码了。各个组件的使用方法请参阅它们各自的文档。



### 组件

#### BaseLayout

##### P8ListLayout

上下结构布局

![1619419572908](1619419572908.png)

可传参数`headerVisible`控制north的隐藏与显示

```vue
<p8-list-layout :headerVisible="false">
	<template #north>
	...//自定义头部区域的内容
	</template>
	<template #center>
	...//自定义中部显示区域的内容
	</template>
    <template #drawer-panel>
	...//自定义页面抽屉弹出区域的内容
	</template>
</p8-list-layout>
```

###### Options

| 属性          | 描述                  | 类型    | 默认值 |
| ------------- | --------------------- | ------- | ------ |
| headerVisible | 控制north的隐藏与显示 | Boolean | true   |

###### Scoped Slot

| name         | 说明                         |
| ------------ | ---------------------------- |
| north        | 自定义头部区域的内容         |
| center       | 自定义中部显示区域的内容     |
| drawer-panel | 自定义页面抽屉弹出区域的内容 |



##### P8NormalLayout

上左右结构

![1619419743498](1619419743498.png)

```vue
<p8-normal-layout :headerVisible="false" // headerVisible控制north的隐藏与显示
               :normalLayout="normalLayout" // normalLayout控制左右部分各占多少栅格
               :splitLayout="splitLayout" // 是否开启拖拽功能
               :splitDefaultLeftWidth="splitDefaultLeftWidth" // 开启拖拽功能后左边布局默认占多少栅格
               >
	<template #north>
	...//自定义头部区域的内容
	</template>
	<template #west>
	...//自定义中部显示区域的内容
	</template>
	<template #center>
	...//自定义页面抽屉弹出区域的内容
	</template>
</p8-normal-layout>
```

normalLayout默认栅格配置：

```json
normalLayout：{
  west: {
	xs:  8, sm:  7, md:  6, lg:  5, xl:  4
  },
  center: {
	xs:  16, sm:  17, md:  18, lg:  19, xl:  20
  }
}
xs	<768px
sm	≥768px
md	≥992px
lg	≥1200px
xl	≥1920px
```

###### Options

| 属性           | 描述                             | 类型    | 默认值 |
| -------------- | -------------------------------- | ------- | ------ |
| headerVisible  | 控制north的隐藏与显示            | Boolean | true   |
| normalLayout   | 中部显示区域栅格配置             | Object  |        |
| westFullHeight | 中部显示区域左侧区域显示高度100% | Boolean | false  |

###### Scoped Slot

| name         | 说明                         |
| ------------ | ---------------------------- |
| north        | 自定义头部区域的内容         |
| center       | 自定义中部显示区域的内容     |
| drawer-panel | 自定义页面抽屉弹出区域的内容 |



##### P8SplitPane

上下或左右拖拽布局

```vue
  <p8-split-pane v-on:resize="resize" 
              :min-percent='20' 
              :default-percent='30' 
              split="vertical">
      <template slot="paneL">
        A
      </template>
      <template slot="paneR">
        B
      </template>
    </p8-split-pane>
```

```vue
 //nested
   <p8-split-pane v-on:resize="resize" 
               :min-percent='20' 
               :default-percent='30' 
               split="vertical">
      <template slot="paneL">
        A
      </template>
      <template slot="paneR">
        <p8-split-pane split="horizontal">
          <template slot="paneL">
           B
          </template>
          <template slot="paneR">
            C
          </template>
        </p8-split-pane>
      </template>
    </p8-split-pane>
```

###### Options

| 属性        | 描述                 | 类型                         | 默认值           |
| ----------- | -------------------- | ---------------------------- | ---------------- |
| split       | 水平还是垂直         | String [horizontal,vertical] | 必须选择一种类型 |
| min-percent | 面板最大-最小-百分比 | Number                       | 10               |
| max-percent | 面板最大百分比       | Number                       | 10               |



##### P8NlcrLayout

上左中右结构布局

![1619420471101](1619420471101.png)

```vue
<p8-nlcr-layout 
            :headerVisible="false" // headerVisible控制north的隐藏与显示
            :normalLayout="normalLayout" // normalLayout控制左中右部分各占多少栅格
            :leftUsePerfectScrollbar="leftUsePerfectScrollbar"// 左侧布局使用滚动条 默认true 
            >
    		<template #north>
            ...//自定义头部区域的内容
            </template>
            <template #left>
            ...//自定义左侧显示区域的内容
            </template>
            <template #center>
            ...//自定义中部显示区域的内容
            </template>
    		<template #right>
            ...//自定义右侧显示区域的内容
            </template>
            <template #drawer-panel>
            ...//自定义页面抽屉弹出区域的内容
            </template>
</p8-nlcr-layout>
```

normalLayout默认栅格配置：

```json
normalLayout: {
      type: Object,
      default: function () {
        return {
          left: {
            xs: 8, sm: 7, md: 6, lg: 5, xl: 4
          },
          center: {
            xs: 8, sm: 10, md: 12, lg: 14, xl: 16
          },
          right: {
            xs: 8, sm: 7, md: 6, lg: 5, xl: 4
          }
        }
      }
    }
xs	<768px
sm	≥768px
md	≥992px
lg	≥1200px
xl	≥1920px
```

###### Options

| 属性                    | 描述                                                | 类型    | 默认值 |
| ----------------------- | --------------------------------------------------- | ------- | ------ |
| headerVisible           | 控制north的隐藏与显示                               | Boolean | true   |
| normalLayout            | 中部显示区域栅格配置                                | Object  |        |
| leftUsePerfectScrollbar | 中部显示区域左侧区域使用vue-perfect-scrollbar滚动条 | Boolean | true   |

###### Scoped Slot

| name         | 说明                         |
| ------------ | ---------------------------- |
| north        | 自定义头部区域的内容         |
| left         | 自定义左侧显示区域的内容     |
| center       | 自定义中部显示区域的内容     |
| right        | 自定义右侧显示区域的内容     |
| drawer-panel | 自定义页面抽屉弹出区域的内容 |



##### P8MenuLayout

三级菜单布局

![1619420833727](1619420833727.png)

```vue
<p8-menu-layout :thirdMenuParam="thirdMenuParam" // 给三级菜单所传的参数
                :defaultMenu="defaultMenu" // 默认选中的三级菜单
                :filterThirdMenu="filterThirdMenu"// 是否要过滤三级菜单
                :cache="cache"> // 是否启用keep-alive缓存
</p8-menu-layout>
```

###### Options

| 属性            | 描述                                                | 类型    | 默认值 |
| --------------- | --------------------------------------------------- | ------- | ------ |
| thirdMenuParam  | 菜单页面需要传递的props参数                         | Object  | {}     |
| defaultMenu     | 默认选中菜单                                        | Object  | {}     |
| filterThirdMenu | 过滤菜单， 值为路由的name； 过滤多个时， 以逗号拼接 | String  | ‘’     |
| cache           | 是否启用缓存                                        | Boolean | true   |

defaultMenu 例子： {"path":"/planManager"}

路由 例子：[{"path":"/planManager","name":"planManager","component":{"_custom":{"type":"function","display":"<span>ƒ</span> ()"}},"meta":{"id":"030211","title":"计划编制","icon":"fdddfont icon-personstalker"}},{"path":"/planChangeManager","name":"planChangeManager","component":{"_custom":{"type":"function","display":"<span>ƒ</span> ()"}},"meta":{"id":"030213","title":"计划变更","icon":"fdddfont icon-personstalker"}},{"path":"/planWarningManager","name":"planWarningManager","component":{"_custom":{"type":"function","display":"<span>ƒ</span> ()"}},"meta":{"id":"030214","title":"计划预警","icon":"fdddfont icon-personstalker"}}]

##### P8Anchor

![image-20210323160217123](image-20210323160217123.png)

- props字段说明

  - menu(Array): 锚点导航菜单

    ```javascript
    格式: [
        {
            label: 测试1，
            value： 'test1'
        },
        {
            label: 测试2，
            value： 'test2'
        }
    ]
    会根据value值提供具名插槽, 使用时 <template #test2>...</template>
    ```

  - menuKey(Object):  重新绑定label和value字段

    ```javascript
    如果menu数组中的对象不含lebel和value, 而是别的如: text(对应label), id(对应value), 此时可通过menuKey进行重新绑定
    ```

  - placement: menu导航出现的位置

    ```javascript
    top / right / left
    ```

- computed说明

  - renderPlacementStyle / renderContentHeight / renderSliderStyle

    ```javascript
    根据 placement 字段值, 进行样式区分, 返回声明好的类名或样式
    ```

- methods说明

  - sliderClickHandle(): 点击menu菜单, 跳转至对应内容区
  - scrollAreaHandle(): 内容区滚动监听, 使menu菜单(当前高亮)和内容区对应 [还有问题, 待优化]

###### Options

| 属性      | 描述                                    | 类型     | 默认值                                                       |
| --------- | --------------------------------------- | -------- | ------------------------------------------------------------ |
| menu      | 锚点导航数组                            | Array(*) | []                                                           |
| menuKey   | 重新绑定label和value字段                | Object   | {<br/>          label: 'label',<br/>          value: 'value'<br/>        } |
| placement | menu出现的位置,可选（top, right, left） | String   | 'left'                                                       |



##### P8Bpm

- 参考链接

  ```javascript
  1. https://bpmn.io/
  2. https://blog.csdn.net/juny0302/article/details/106074714/
  3. https://juejin.cn/post/6844904017567416328
  4. https://blog.csdn.net/qq_39211165/article/details/109152644
  ```

- index.vue: 创建流程

- P8ProcessDefinition: 查看流程图, 不带审批信息悬浮面板

- P8ProcessApproval: 查看流程图, 带审批悬浮信息面板

  ```javascript
  1. 审批悬浮面板分为 节点审批信息 / 预先审批人信息[节点类型为UserTask]
  2. 悬浮面板实现思路: 对UserTask类型的节点添加一层透明遮罩(overlzysMask()方法),BPM会在DOM元素中生成类名"djs-overlays"的元素, 获取所有该类名的元素, 使用原生JS进行enter和leave鼠标监听事件(customBpmnListener()),实现面板的隐藏和显示
  3. 节点和线条颜色渲染: 定义scss文件(custom.style.scss),声明约定好色值的类名, 再根据BPM提供的方法,添加对应的类名(approvalEleStyleHandle(): 节点填充; flowEleStyleHandle(): 线条填充)
  ```

###### Options

| 属性    | 描述        | 类型               | 默认值 |
| ------- | ----------- | ------------------ | ------ |
| api     | 获取数据api | String             | ''     |
| bpmId   | id          | String \|\| Number |        |
| bpmName | name        | String             |        |

##### 

##### P8Button

![1616488081476](1616488081476.png)

```vue
<p8-button :comp="comp" 
           :selectRecords="selectRecords"
           :specialRoteName="specialRoteName"
           :parentButtonId="parentButtonId"
           :customButtonData="customButtonData">
</p8-button>
```



- data中声明 comp(Object):  this
  methods中写数据库中对应方法 例如createProject(){}
- selectRecords(Boolean)：当前列表选中的行记录，默认为[]，用来控制header中按钮的禁用与隐藏；
- specialRoteName(String)：按三级菜单的name来查询权限按钮，默认为''
- parentButtonId(String)：权限按钮如果有子的话传入该按钮的id，默认为''
- customButtonData(Array)：智能报表中新增的按钮，默认为[]，可concat在页面原本的权限按钮中
- 按钮禁用规则配置在p8-backend-flatfrom\p8-bpm\src\main\resources\bpmn\DecisionButtonEnable.dmn，里边有样例，可参考；

###### Options

| 属性             | 描述                               | 类型   | 默认值 |
| ---------------- | ---------------------------------- | ------ | ------ |
| comp             | 实例this                           | Object | {}     |
| specialRoteName  | 按三级菜单的name来查询权限按钮     | String | ‘’     |
| parentButtonId   | 权限按钮如果有子的话传入该按钮的id | String | ‘’     |
| selectRecords    | 列表选中的行记录                   | Array  | []     |
| customButtonData | 智能报表中新增的按钮               | Array  | []     |

##### 

##### P8Card

```vue
<p8-card :headerVisible="headerVisible"></p8-card>
```

- headerVisible(Boolean)：卡片头部是否要隐藏，默认为true（显示）

###### Options

| 属性          | 描述                   | 类型    | 默认值 |
| ------------- | ---------------------- | ------- | ------ |
| headerVisible | 控制header的隐藏与显示 | Boolean | true   |

###### Scoped Slot

| name    | 说明                 |
| ------- | -------------------- |
| header  | 自定义头部区域的内容 |
| content | 自定义内容显示区域   |

##### P8Dialog

![1616488201856](1616488201856.png)

```vue
<p8-dialog width="50%"
               title="选择型号"           
               :visible="visible"
               :showHandleBtn="true"
               :dialogConfig="dialogConfig"
               :dialogHeight="dialogHeight"
               :isViewCsFooter="isViewCsFooter"
               @close="close" // 点击关闭按钮触发的方法
               @handle-cancel="handleCancel" // 点击取消按钮触发的方法
               @handle-ok="handleOk" // 点击确定按钮触发的方法
               @isfullscreen="isfullscreen" // 全屏触发事件>
	<template #dialog>
	...
	</template>
</p8-dialog>
```

- width(String)：dialog的宽度，默认为50%
- title(String)：dialog的title，默认为''
- showHandleBtn(Boolean)：是否显示脚步，默认为true
- visible(Boolean)：dialog是否显示，默认为false
- dialogConfig(Object)：dialog组件的其它属性（可在element ui中查找相应api）
- dialogHeight(Number)：dialog的高度，默认为400
- isViewCsFooter(Boolean)：是否显示自定义脚部，默认为false，不显示

###### Options

| 属性           | 描述                                                | 类型           | 默认值 |
| -------------- | --------------------------------------------------- | -------------- | ------ |
| width          | dialog的宽度                                        | String\|Number | '50%'  |
| title          | dialog的title                                       | String         | ''     |
| showHandleBtn  | 是否显示脚部                                        | Boolean        | true   |
| visible        | dialog是否显示                                      | Boolean        | false  |
| dialogConfig   | dialog组件的其它属性（可在element ui中查找相应api） | Object         | {}     |
| dialogHeight   | dialog的高度                                        | Number         | 400    |
| isViewCsFooter | 是否显示自定义脚部                                  | Boolean        | false  |

###### Scoped Slot

| name      | 说明               |
| --------- | ------------------ |
| dialog    | 自定义弹框内容区域 |
| cs-footer | 自定义底部显示区域 |

##### P8Cron

##### P8Drawer

![1616488311908](1616488311908.png)

```vue
<p8-drawer size='80%'
           :title="title"
           :visible="visible"
           :direction="direction"
           :size="size"
           :drawerConfig="drawerConfig"
           :showHandleBtn="false"
           :beforeClose="beforeClose"
           @close="close"> // 抽屉关闭触发的方法
	<template #drawer>
	...
	</template>
</p8-drawer>
```

- title(String)：抽屉组件的title
- visible(Boolean)：抽屉组件是否显示
- direction(String)：抽屉弹出的方向，默认为从右往左开
- size(String)：抽屉窗体的大小，默认为50%
- drawerConfig(Object)：抽屉组件的其它属性（可在element ui中查找相应api）
- isNeedCustomDrawerClass(Boolean)：是否为抽屉组件加自定义类名(.custom-drawer)，控制title不显示的时候抽屉组件的样式，默认为false
- beforeClose(Function)： 抽屉关闭前的回调，会暂停 Drawer 的关闭 

###### Options

| 属性                    | 描述                                                         | 类型     | 默认值 |
| ----------------------- | ------------------------------------------------------------ | -------- | ------ |
| title                   | 抽屉组件的title                                              | String   | ''     |
| direction               | 抽屉弹出的方向，默认为从右往左开(rtl / ltr / ttb / btt)      | String   | 'rtl'  |
| visible                 | dialog是否显示                                               | Boolean  | false  |
| size                    | 抽屉窗体的大小                                               | String   | '50%'  |
| drawerConfig            | 抽屉组件的其它属性（可在element ui中查找相应api）            | Object   | {}     |
| isNeedCustomDrawerClass | 是否为抽屉组件加自定义类名(.custom-drawer)，控制title不显示的时候抽屉组件的样式，默认为false | Boolean  | false  |
| beforeClose             | 抽屉关闭前的回调，会暂停 Drawer 的关闭                       | Function |        |

###### Scoped Slot

| name        | 说明               |
| ----------- | ------------------ |
| titleHeader | 自定义头部内容区域 |
| drawer      | 自定义内容显示区域 |



##### P8FileView

![image-20210323160011553](image-20210323160011553.png)

- props字段说明

  - uploadFiles(Array): 文件列表
  - filesLayout(String): 列表展示类型 [row / card]
  - fileDownloadKey(Object):  文件下载所需字段重新绑定

- 使用

  - 单独使用

    ```vue
    按需引入并声明,进行使用
    <p8-file-view
      :uploadFiles="uploadFiles"
      filesLayout="card"
    ></p8-file-view>
    ```
```
  
- 在form表单中进行使用
  
    ```vue
    1. 按需引入p8Components/form,
    2. 表单配置项中type字段声明为"uploadView"
    <template>
            <form-list ref="form"
                       @saved="saved"
                       @rendered="rendered"
                       :dataSource="dataSource"
                       :api="saveApi"
                       :form="formData"
                       @close="closeModal"
            >
            </form-list>
    </template>
    // 表单配置项
    dataSource: [
        {
          type: 'uploadView', // form查看带文件
          filesLayout: 'row', // 附件展示类型[row / card; 默认card]
          labelText: '文件',
          fieldName: 'uploadFiles',
          placeholder: '',
          colLayout: ''
        },
    ]
```

###### Options

| 属性            | 描述                                                         | 类型   | 默认值                                                       |
| --------------- | ------------------------------------------------------------ | ------ | ------------------------------------------------------------ |
| uploadFiles     | 文件列表                                                     | Array  | []                                                           |
| fileDownloadKey | 文件下载所需字段重新绑定: 根据传递值, 在文件下载时 获取到对应的文件信息 | Object | {<br/>          id: 'id',<br/>          fileName: 'fileName',<br/>          confValueKey: 'confidentialite'<br/>        } |
| filesLayout     | 列表展示类型 [row / card]                                    | String | 'card'                                                       |



##### P8SelectUser

![1616488377887](1616488377887.png)

```vue
<p8-select-user :visible="visible"
                :disabledRow="disabledRow"
                :otherParam="otherParam"
                :selectType="selectType"
                :dialogConfig="dialogConfig"
                @close-dialog="closeDialog"> // 点击确定或取消后触发
</p8-select-user>
```

- visible(Boolean)：控制人员选择器的显示与隐藏，默认隐藏

- disabledRow(Array)：控制人员列表中哪些行置灰

- otherParam(Object)：为人员选择器传递的其它参数，用于筛选人员列表

- selectType(String)：控制人员选择器为单选还是多选，默认为"0"，多选

- dialogConfig(Object)：人员选择器添加在dialog组件的其它属性（可在element ui中查找相应api）

- treeOptions(Object)：左侧树的配置对象，参考P8Tree 

  默认值：{

  ​     treeApi: 'userManager.deptTree',

  ​     treeParam: {},

  ​     disabledRow: ['1'],

  ​     defaultExpandAll: true,

  ​     defaultExpandedKeys: ['1'],

  ​     treeConfig: {

  ​      'expand-on-click-node': false,

  ​      'check-on-click-node': true

  ​     }

  ​    }

###### Options

| 属性         | 描述                                                         | 类型    | 默认值 |
| ------------ | ------------------------------------------------------------ | ------- | ------ |
| visible      | 控制人员选择器的显示与隐藏，默认隐藏                         | Boolean | false  |
| disabledRow  | 控制人员列表中哪些行置灰                                     | Array   | []     |
| otherParam   | 为人员选择器传递的其它参数，用于筛选人员列表                 | Object  | {}     |
| selectType   | 控制人员选择器为单选还是多选，默认为"0"                      | String  | '0'    |
| dialogConfig | 员选择器添加在dialog组件的其它属性（可在element ui中查找相应api） | Object  | {}     |
| treeOptions  | 左侧树的配置对象，参考P8Tree                                 | Object  | {      |

##### P8IconSelector

##### P8Import

##### P8InfiniteScroll

![1616489508368](1616489508368.png)

```vue
<p8-infinite-scroll :keyName="keyName"
                    :listApi="listApi"
                    :activeItem="activeItem"
                    :searchParams="searchParams"
                    :removedItem="removedItem"
                    @load="load" // 列表数据加载完成后触发
                    @onSelect="onSelect"> // 列表某一项被选中后触发
</p8-infinite-scroll>
```

- keyName(String)：列表行记录的唯一标志，默认为id
- listApi(String)：滚动列表的api
- activeItem(Number)：当前选中的列表的下标
- searchParams(Object)：列表的查询条件
- removedItem(String)：要删除（过滤）的行记录，通过“keyName”来判断

###### Options

| 属性         | 描述                                        | 类型   | 默认值 |
| ------------ | ------------------------------------------- | ------ | ------ |
| keyName      | 列表行记录的唯一标志，默认为id              | String | 'id'   |
| listApi      | 滚动列表的api                               | String |        |
| activeItem   | 当前选中的列表的下标                        | Number |        |
| searchParams | 列表的查询条件                              | String | {}     |
| removedItem  | 要删除（过滤）的行记录，通过“keyName”来判断 | String | ''     |

###### Scoped Slot

| name | 说明                 |
| ---- | -------------------- |
| list | 自定义行记录显示内容 |



##### P8StatusIcon

![1616573229787](1616573229787.png)

```vue
<p8-status-icon :statusName="statusName"
                    :statusKey="statusKey"
                    @iconClick="iconClick"> // 点击标识后触发
</p8-status-icon>
```

- statusName(String)：状态名称，例如：“taskStatus”为任务状态等
- statusKey(String)：项目状态/计划状态/任务状态key

###### Options

| 属性       | 描述                                     | 类型   | 默认值 |
| ---------- | ---------------------------------------- | ------ | ------ |
| statusName | 状态名称，例如：“taskStatus”为任务状态等 | String | ''     |
| statusKey  | 项目状态/计划状态/任务状态key            | String | ''     |



##### P8Table

![1616573689436](1616573689436.png)

```vue
<p8-table ref="table"
              :comp="comp" // this对象，配置表格数据行中的按钮
              :size="size" // table的尺寸，默认为small
              :isStripe="isStripe" // 是否设置为斑马纹，默认设置为true
              :minHeight="minHeight" // table的最小高度
  			  :columns="columns" 
              :pagination="pagination" // 是否展示分页，默认展示分页
              :paginationInfo="paginationInfo" // 额外设置table分页信息
  			  :tableRefresh="tableRefresh" // 调用列表接口后的回调方法
              :params="params" // 列表查询条件
              :api="api" // 列表api
              :parentButtonId="parentButtonId" // 权限按钮如果有子的话传入该按钮的id
              :specialRoteName="specialRoteName" // 按三级菜单的name来查询权限按钮，默认为''
  			  :tableConfig="tableConfig" // table自定义属性
              :hiddenRootOperation="hiddenRootOperation" // 树形table根据所传参数控制根操作列的显示与隐藏
              :useTreeFormat="useTreeFormat" //  是否是treeTable，数据格式为平行数组，通过pId或parentId来转换
              :useTreePId="useTreePId" // 如果useTreeFormat设置为true，默认通过pId来转换数据格式
              :noApiTableData="noApiTableData" // 父组件没有传递api，直接传递table的数据
              :tableSetting="tableSetting" //  是否展示表格设置图标[true:展示--可操作表格; false:不展示--不可操作表格]
              :customButtonData="customButtonData" // 智能报表中新增按钮
              :customHeight="customHeight" // table的自定义高度
              :merageKeys="merageKeys" // 要纵向合并的单元格的key数组
              :showOverflowTooltip="showOverflowTooltip" // 默认列内容过长被隐藏时显示 tooltip
              :filterThirdMenu="filterThirdMenu" // 过滤三级菜单， 值为路由的name；  过滤多个时， 以逗号拼接
              :disabledCheckAll="disabledCheckAll" // 是否需要全选功能(前提: table带勾选功能), true:隐藏全选
              :customButtonConfig="customButtonConfig" // 智能报表中按钮的禁用规则
              :selectAllHidden="selectAllHidden" // 隐藏列表表头的复选框
              :rowClassNameCalc="rowClassNameCalc" // 设置行类名
              :showSearchRow="showSearchRow" // table表头默认不显示查询行
              @selection-change="handleSelectionChange" // 当选项发生变化时会触发该事件
              @select="select" // 当用户手动勾选数据行的Checkbox时触发的事件
              @select-all="selectAll" // 当用户手动勾选全选Checkbox时触发的事件
              @cell-click="cellClick" // 当某个单元格被点击时会触发该事件
              @row-click="rowClick" // 当某一行被点击时会触发该事件
              @row-dblclick="rowDblclick" // 当某一行被双击时会触发该事件
              @sort-change="sortChange" // 当表格的排序条件发生变化的时候会触发该事件
              @current-change="currentChange" // 当表格的当前行发生变化的时候会触发该事件，如果要高亮当前行，请打开表格的highlight-current-row 属性
              :span-method="margeHandle" // 合并行或列的计算方法
  >
	<template #icon="{scope}">//自定义列
	  <span @click="iconClick(scope)">123456</span>
	</template>
</p8-table>
```

- **1> 对于简单的列渲染，比如说“百分比”，需要乘以100然后再加上“%”，可以直接使用formatter方法：**

  formatter	用来格式化内容	Function(row, column, cellValue, index)
   [Element UI Table表格](https://element.eleme.cn/#/zh-CN/component/table)

  ```vue
  columns = [
  	{
  		title: '完成百分比',
          dataIndex: 'progress',
          width: 80,
          align: 'center',
          formatter: function (row) {
            if (row.dataType === 'task') {
              return row.progress * 100 + '%'
            }
          }
  	}
  ]
  ```

  **2> 对于复杂的列渲染，比如说列上要渲染一个图标，鼠标悬浮到图标上要调接口获取显示的悬浮信息，这个时候可以用到：**

  scopedSlots: {
      customRender: 'custom'
  }
  
  ```vue
  {
      title: '状态',
      type: 'index',
      dataIndex: 'executeState',
      scopedSlots: { customRender: 'custom' },
      width: 60
  }
  ```
  
  **3> 对于复杂的列渲染，列表三级菜单列：**
  
  scopedSlots: {
      customRender: 'thirdMenu'
  }
  
  ```vue
  {
      title: '状态',
      type: 'index',
      dataIndex: 'executeState',
      scopedSlots: { customRender: 'thirdMenu' },
      width: 60
  }
  ```
  
  4>列表操作列 ：**
  
  scopedSlots: {
      customRender: 'operation'
  }
  
  ```vue
  {
      title: '状态',
      type: 'index',
      dataIndex: 'executeState',
      scopedSlots: { customRender: 'operation' },
      width: 60
  }
  ```
  
  **4> 多级表头 ：columns支持嵌套**
  
  ```vue
  {
      title: '状态',
      type: 'index',
      dataIndex: 'executeState',
      scopedSlots: { customRender: 'operation' },
      width: 60,
  	chlidren: [
  		{
  			title: '状态',
              type: 'index',
              dataIndex: 'executeState',
              scopedSlots: { customRender: 'thirdMenu' },
              width: 60
          }
  	]
  }
  ```
  
  

注意：**

- 大部分行数据按钮在commonTable中已做处理，按钮禁用规则配置在p8-backend-flatfrom\p8-bpm\src\main\resources\bpmn\DecisionButtonEnable.dmn，里边有样例，可参考。剩余一小部分逻辑比较复杂的需按照以下所示方法处理；

- 行数据上按钮对应的方法名为数据库中eventHandle字段对应的方法名，有两个参数（record,button）,record为当前行记录，button为当前点击的按钮；

- 表格中行记录上按钮禁用与悬浮信息提示需自定义方法：

  ```vue
  disabled (record, button, arr) {
  	record  // 当前行记录
  	button  // 当前点击的按钮
  	arr  // ['disabled','disabledMsg']
  	return {
  	  arr[0]:  true  or  false,
  	  arr[1]:  按钮禁用提示
  	}
  }
  ```

注意：
  - **disabled**方法是当前按钮在数据库中isDisabled字段对应的方法名，如果该按钮不禁用的话，则isDisabled字段为''或者null，如果要禁用的话isDisabled字段需传对应的方法名（在上面的代码中isDisabled字段就为disabled）；
  - 禁用方法有三个参数（record,button,arr）,record为当前行记录，button为当前点击的按钮,arr为一个固定的数组；
  - 方法返回一个对象，分别是按钮是否禁用及禁用后鼠标悬浮的提示信息;
  - 按钮禁用规则配置在p8-backend-flatfrom\p8-bpm\src\main\resources\bpmn\DecisionButtonEnable.dmn，里边有样例，可参考；

- 自定义数据列 template “#”后面的名称为columns中对应列的dataIndex值;

- 在table上增加服务器端排序功能、在列上增加输入框，回车搜索功能，方法如下：

  ```vue
  columns: [
  {
      title: '用户名称',
      dataIndex: 'userName',
  	width: '', // 对应列的宽度(string)
  	minWidth: '', //对应列的最小宽度，与 width 的区别是 width 是固定的，min-width 会把剩余宽度按比例分配给设置了 min-width 的列(string)
  	reserveSelection: true, //仅对 type=selection 的列有效，类型为 Boolean，为 true 则会在数据更新之后保留之前选中的数据（需指定 row-key）
      selectable: function(){},// 仅对 type=selection 的列有效，类型为 Function，Function 的返回值用来决定这一行的 CheckBox 是否可以勾选
  	fixed: false, //列是否固定在左侧或者右侧，true 表示固定在左侧 (true, left, right)
  	formatter:	function(){},//用来格式化内容	Function(row, column, cellValue, index)
  	columnConfig: {}, 参考element-ui -> el-table -> Table-column Attributes
      filterable: true, // 列上增加输入框搜索,同时要添加filter
      iconDisplay: false, // 表头点击搜索图标，出现搜索条件
      sortable: true // 服务器端排序
  	elSortable：true/ false/ 'custom' //'custom'，服务器端排序，true 前端排序
      filter: {
  		alias: 'realName', // dataIndex 对应过滤字段的别名
       	val: '', // 查询条件绑定的v-model
       	type: 'multiple', // 查询条件type，判断为输入框或下拉框等
       	optionUrl: { // 查询条件数据字典
        		api: 'thirdPartInterface.getDic',
         		params: { dicType: 'EXECUTE_STATE' },
  			label: 'name',
  			value: 'id'
       	}
     	}
  }]
  ```

###### Options

| 属性                | 描述                                                         | 类型     | 默认值  |
| ------------------- | ------------------------------------------------------------ | -------- | ------- |
| comp                | this对象，配置表格数据行中的按钮                             | Object   | {}      |
| intelligenceComp    | 智能报表中配置的按钮this                                     | Object   | {}      |
| size                | table的尺寸，默认为small                                     | String   | 'small' |
| minHeight           | 列表的最小高度                                               | Number   | 350     |
| columns             | 列头                                                         | columns  | []      |
| pagination          | 是否展示分页，默认展示分页                                   | Boolean  | true    |
| paginationInfo      | 额外设置table分页信息                                        | Object   | {}      |
| tableRefresh        | 调用列表接口后的回调方法                                     | Function |         |
| params              | 列表查询条件                                                 | Object   | {}      |
| api                 | 列表api                                                      | String   | ''      |
| parentButtonId      | 权限按钮如果有子的话传入该按钮的id                           | String   | ''      |
| specialRoteName     | 按三级菜单的name来查询权限按钮                               | String   | ''      |
| tableConfig         | table自定义属性                                              | Object   | {}      |
| menuState           |                                                              | Array    | []      |
| hiddenRootOperation | 树形table根据所传参数控制根操作列的显示与隐藏                | Boolean  | false   |
| useTreeFormat       | 是否是treeTable，数据格式为平行数组，通过pId或parentId来转换 | Boolean  | false   |
| useTreePId          | 如果useTreeFormat设置为true，默认通过pId来转换数据格式       | String   | 'pId'   |
| noApiTableData      | 父组件没有传递api，直接传递table的数据                       | Array    | []      |
| tableSetting        | table自定义属性                                              | Boolean  | true    |
| customButtonData    | 智能报表中新增按钮                                           | Array    | []      |
| customHeight        | table的自定义高度                                            | Number   | 0       |
| merageKeys          | 要纵向合并的单元格的key数组                                  | Array    | []      |
| showOverflowTooltip | 默认列内容过长被隐藏时显示 tooltip                           | Boolean  | true    |
| filterThirdMenu     | 过滤三级菜单， 值为路由的name； 过滤多个时， 以逗号拼接      | String   | true    |
| disabledCheckAll    | 是否需要全选功能(前提: table带勾选功能), true:隐藏全选       | Boolean  | false   |
| isRadioSelect       | 是否需要单选功能(前提: table带勾选功能), true:隐藏全选       | Boolean  | false   |
| customButtonConfig  | 智能报表中按钮的禁用规则                                     | Array    | []      |
| selectAllHidden     | 隐藏列表表头的复选框                                         | Boolean  | false   |
| showSearchRow       | table表头默认显示查询行                                      | Boolean  | false   |
| countSizeRowHeight  | 计算请求size数量-表格行高                                    | Number   | 40      |



##### P8Tabs

![1619404343085](1619404343085.png)

![1619404297261](1619404297261.png)

```vue
<p8-tabs ref="tabs"
         :type="type" // 风格类型	card/border-card
         :tabPosition="tabPosition" //选项卡所在位置	top/right/bottom/left
         :tabsData="tabsData" // tabs数据，以数据的形式，每一项都为{label: '审批内容',name: 'approval'}形式
         :height="height" // tabs的高度
         :activeTabs="activeTabs" // 默认选中哪个tab页
         @tab-click="tabClick"> // tabs的单击事件
    <template #approval_label>// label区域插槽（插槽名根据tabsData的name动态变化：name+'_label'）
    </template>
    <template #approval>// 内容区域插槽（插槽名根据tabsData的name动态变化）
    </template>
</p8-tabs>
```

###### Options

| 属性        | 描述                                                         | 类型   | 默认值       |
| ----------- | ------------------------------------------------------------ | ------ | ------------ |
| type        | 风格类型	card/border-card                                 | String | ''           |
| tabPosition | 选项卡所在位置	top/right/bottom/left                      | String | 'top'        |
| tabsData    | tabs数据，以数据的形式，每一项都为{label: '审批内容',name: 'approval'}形式 | Array  | []           |
| height      | tabs的高度                                                   | String | 'fullHeight' |
| activeTabs  | 默认选中哪个tab页                                            | String | ''           |

###### Scoped Slot

| name                                | 说明                  |
| ----------------------------------- | --------------------- |
| tabsData的name字段对应的值          | 自定义tabs显示内容区  |
| tabsData的name字段对应的值+‘_label’ | 自定义label显示内容区 |



##### P8Tree

![1619406972889](1619406972889.png)

```vue
<p8-tree ref="tree"
         :treeApi="treeApi" // 树api
         :defaultExpandAll="defaultExpandAll" // 默认展开全部节点
         :defaultExpandedKeys="defaultExpandedKeys" // 默认展开的节点
         :treeParam="treeParam" // 树参数
         :disabledRow="disabledRow" // 禁用的树节点
         :data="data" // 树数据，一般为在父页面中已获取到的数据，直接传递到commonTree组件里
         :treeConfig="treeConfig" // 树自定义属性
         :nodeSlot="nodeSlot" // 树插槽，可自定义节点
         @check-change="checkChange" // 节点选中状态发生变化时的回调
         @node-click="nodeClick"> // 节点被点击时的回调
</p8-tree>
```

###### Options

| 属性             | 描述                                                         | 类型    | 默认值 |
| ---------------- | ------------------------------------------------------------ | ------- | ------ |
| treeApi          | 树api                                                        | String  | ''     |
| treeParam        | 树请求参数（配合treeApi使用）                                | Object  | {}     |
| defaultExpandAll | 默认展开全部节点                                             | Boolean | true   |
| disabledRow      | 禁用的树节点 例：[{'id':'00'}]                               | Array   | []     |
| data             | 树数据，一般为在父页面中已获取到的数据，直接传递到commonTree组件里 | Array   | []     |
| treeConfig       | 支持 el-tree props                                           | Object  | {}     |
| nodeSlot         | 是否使用树节点插槽                                           | Boolean | false  |

###### Scoped Slot

| name | 说明                   |
| ---- | ---------------------- |
| tree | 自定义树节点显示内容区 |



##### P8Upload

![image-20210323155904309](image-20210323155904309.png)

```vue
<template>
        <form-list ref="form"
                   :dataSource="dataSource"
                   :api="saveApi"
                   :form="formData"
                   @close="closeModal"
                   @saved="saved"
                   @rendered="rendered">
        </form-list>
</template>
<script>
import { P8Form as FormList } from 'p8-components-ui'
export default {
	components: {
        FormList
    },
    data () {
        return {
            saveApi: '', // 表单保存api接口
            dataSource: [ // 表单数据源配置项
                {
                    labelText: '策划分类', // formItem的lable
                    type: 'select', // form组件中配置项类型, select对应下拉框
                    fieldName: 'classifyId', // 配置项对应后台字段
                    placeholder: '请选策划分类',
                    colLayout: 'singleCol',
                    optionUrl: { // select下拉框时,下拉数据配置项,根据配置项在组件内部获取下拉列表
                        api: 'thirdPartInterface.getDic',
                        params: { dicType: 'PLOT_CLASSIFY' },
                        label: 'label',
                        value: 'value'
                    },
                    options: [], // select下拉框默认下拉列表, 优先级最高
                    rules: [ // 表单配置项的校验
                        {
                            required: true,
                            message: '必填'
                        }]
                },
                {
                    labelText: '文件名称',
                    type: 'text', // text对应输入框
                    fieldName: 'name',
                    placeholder: '请输入文件名称',
                    colLayout: 'singleCol',
                    rules: [
                        {
                            required: true,
                            message: '必填'
                        }
                    ]
                },
                {
                    type: 'upload', // upload对应上传附件组件
                    labelText: '文件上传', 
                    fieldName: 'getFile',
                    colLayout: 'singleCol',
                    uploadConfig: {
                    },
                    listType: 'secret' // 带密级的上传附件为'secret'，不带密级的listType分为'text'、'picture'、'picture-card'
                }
            ]
        }
    }
}
</script>
```

- index.vue (默认文件)

  - props字段说明

    ```javascript
    1. files(Array): 附件列表
    2. listType(String): 附件列表展示类型(secret(带密级,下拉选择) / custom(自定义,即不需要密级列表和element提供的列表) / [text / picture / picture-card](elementUI提供)])
    3. uploadSlot(Boolean): 附件上传按钮自定义插槽
    4. uploadConfig(Object): 上传附件绑定el-upload提供的其他属性
    ```
  - computed说明
    
  1. renderFiles(): el-upload提供的文件列表展示时使用(即listType = [text / picture / picture-card]), el-upload自带文件列表展示时需要 name 和 url 字段
  
  - methods说明

    - initListType()

      ```javascript
      1. 上传附件文件列表展示类型处理. 当listType="secret"(密级)时, 走fileList.vue组件
      ```

    - beforeUpload(file)

      ```javascript
      1. el-upload上传文件之前的钩子(:before-upload="beforeUpload")
      2. 此处进行文件大小的限制(目前前后台约定好限制500M,前后台都有做限制的处理)
      ```

    - beforeRemove(file)

    ```javascript
    1. el-upload删除文件之前的钩子(:before-remove="beforeRemove")
    ```

    - handleExceed(file, fileList)

    ```javascript
    1. el-upload文件超出个数限制时的钩子(:on-exceed="handleExceed")
    2. 此处根据 files.length + this.uploadConfig.limit(el-upload最大允许上传个数)总和,进行限制处理 
    ```

    - handleSuccess (response, file, fileList)

    ```javascript
    1. el-upload文件上传成功时的钩子(:on-success="handleSuccess")
    2. 上传之后,手动$set密级字段(confidentialite),避免接口返回的文件信息无密级字段时, 密级选择回填不刷新的问题
    3. 若uploadConfig中multiple(多选)为true时(即一次可选择多个文件一并上传),进行了延迟处理, 小文件没问题, 大文件上传时此处会有缺陷.
    ```

    - handleRemove(file, fileList)

    ```javascript
    1. el-upload文件列表移除文件时的钩子(:on-remove="handleRemove")
    ```

    - handlePreview(file)

    ```javascript
    1. el-upload点击文件列表中已上传的文件时的钩子(:on-preview="handlePreview")
    2. 如果listType = "picture-card", 则展示dialog(图片放大); 否则进行文件下载操作
    ```

    - handleRemoveSecret (file)

    ```javascript
    1. 当listType = "secret"时, 密级列表删除事件,向外暴露事件
    ```

    - commonUploadFile /  commonRemoveFile

    ```javascript
    1. 组件提供两个公共方法, 供外部调用
    ```

- fileList.vue(附件列表, 带密级)

  ![image-20210323155951213](image-20210323155951213.png)

  ```javascript
  根据业务需求, 实现密级列表组件. files(Array)中若file.id有值, 则展示效果为第一个红框
  ```
###### Options

| 属性         | 描述                                                         | 类型    | 默认值 |
| ------------ | ------------------------------------------------------------ | ------- | ------ |
| files        | 附件列表                                                     | Array   | []     |
| listType     | 附件列表展示类型: custom(自定义) / secret(带密级) / text / picture / picture-card (elementUI提供) | String  | secret |
| uploadSlot   | 是否使用附件上传插槽, (可自定义上传按钮)                     | Boolean | false  |
| uploadConfig | 支持 el-upload props                                         | Object  | {}     |

###### Scoped Slot

| name   | 说明                                       |
| ------ | ------------------------------------------ |
| upload | 自定义上传显示内容区（配合uploadSlot使用） |



##### P8TreeSelect

##### P8EditTable


![1619414272526](1619414272526.png)

```vue
<p8-edit-table :columns="columns" // table列信息
               :addRow="addRow" // 是否增加增删行操作
               :disabled="disabled" // 禁用: 传参为true: 新建按钮和行删除按钮禁用, 剩余编辑的单元格在当前页面做禁用处理
               :api="api" // 列表api
               :params="params" // 列表参数
               :renderHeight="renderHeight" // 列表自定义高度
               :data="data" // 列表数据
               :needParams="needParams" // 控制哪些列表可传参数，哪些不传，主要用于智能报表
               :deleteCheck="deleteCheck" // 行函数提供判断函数，供外部使用
               :deleteErrorInfo="deleteErrorInfo" // 行函数提供判断函数，供外部使用
               @save-param-data="saveParamData"> // 触发该方法后可获取当前table的最新数据
</p8-edit-table>
```

###### Options

| 属性            | 描述                                                         | 类型     | 默认值  |
| --------------- | ------------------------------------------------------------ | -------- | ------- |
| columns         | table列信息                                                  | Array    | []      |
| addRow          | 是否增加增删行操作                                           | Boolean  | secret  |
| disabled        | 禁用: 传参为true: 新建按钮和行删除按钮禁用, 剩余编辑的单元格在当前页面做禁用处理 | Boolean  | false   |
| api             | 列表api                                                      | String   | ''      |
| params          | 列表查询参数 （配合api使用）                                 | Object   | {}      |
| renderHeight    | 列表高度                                                     | String   | '100%'  |
| data            | 列表数据                                                     | Array    | []      |
| needParams      | 控制哪些列表可传参数，哪些不传，主要用于智能报表             | Boolean  | false   |
| deleteCheck     | 行函数提供判断函数，供外部使用                               | Function |         |
| deleteErrorInfo | 删除提示                                                     | String   | 'error' |



##### P8Form

```vue
<p8-form ref="form"
         :comp="comp" // this对象，配置表单事件
         :dataSource="dataSource" // 渲染表单的json
         :form="formData" // formModel 表单数据对象，隐藏域的值或一些需要声明的值
         :api="saveApi" // 表单保存api
         :isCustomValidate="isCustomValidate" // 保存时是否有自定义校验
         :otherParam="otherParam" // 保存页面自定义的参数
         :existDefaultBtn="existDefaultBtn" // 是否显示表单自带的保存按钮，默认显示，与existCustomBtn对立
         :existCustomBtn="existCustomBtn" // 是否显示自定义的表单按钮，默认不显示，与existDefaultBtn对立
         labelWidth="100px" // label宽度设置
         @rendered="rendered" // 表单所有项都渲染完成后的回调，一般在该方法里获取修改页面的数据
         @saved="saved" // 保存成功后触发的回调
         @custom-validate="customValidate" // 自定义校验的方法
         @form-data-chang="form-data-change"> // 表单任意值变化后都会触发该方法
    <template #password>
	  <el-alert  title="成功提示的文案"  type="success"></el-alert>
	</template>
</p8-form>
```

注意：

- dataSource为渲染表单的json:

```js
dataSource: [
  // 查看控件
  {
        type:  'view',
        labelWidth： '',// lable宽度
        style: { color:'red' },// 自定义样式
        labelText:  '用户名称',
        fieldName:  'userName',
        colLayout:  'doubleCol',// 布局双列 ，单列为空
        tip: '用户名称输入要求：必须包含大写字母与下划线',// 仅对type='view'有效
    	viewOptions: true, //处理编辑类型为(select/radio),view显示对应的label文本 配合optionUrl，options使用
    	optionUrl: {// 异步数据源
            api: 'ProjectApply.getProjectSource', // 下拉数据源api
            params: { dicType: 'TASK_SOURCE' }// 参数
        },
        options: [ // 自定义数据源优先级大于异步数据源
           {
               value:'value',
               label:'label'
           }
        ],
        formatter：(undefined,undefined,value,undefined)=>{// 格式化显示数据
            // TODO
            return ''
        }    
   },
   // 附件查看控件
  {
        type:  'uploadView',
        labelWidth： '',// lable宽度
        style: { color:'red' },// 自定义样式
        labelText:  '用户名称',
        fieldName:  'userName',
        colLayout:  'doubleCol',// 布局双列 ，单列为空
        tip: '用户名称输入要求：必须包含大写字母与下划线',// 仅对type='view'有效
        filesLayout：'row' // row/card   
   }, 
   // 用于页面中展示重要的提示信息。
  {
        type:  'alert',
        labelText:  '用户名称',
        fieldName:  'userName',
        labelWidth:  '',// label宽度
        colLayout:  'doubleCol',// 布局双列 ，单列为空
        effect: '',// 选择提供的主题	string	light/dark 默认light
        alertType: '',// 主题	string	success/warning/info/error	默认info   
        fieldConfig: {// element-ui 对应组件options
        },    
   },     
   // 自定义控件 使用插槽
  {
        type:  'blank',
        labelText:  '用户名称',
        slotName:  'userName',// 插槽名
        labelWidth:  '',// label宽度
        colLayout:  'doubleCol',// 布局双列 ，单列为空
        rules: []
   },
  // 自定义控件 使用插槽
  {
        type:  'addField',
        labelText:  '用户名称',
        fieldName:  'userName',// 插槽名
        labelWidth:  '',// label宽度
        colLayout:  'doubleCol',// 布局双列 ，单列为空
        addFieldLayout: 'horizontal', // horizontal/vertical
        isView: false,// 查看
        children: [
            // 查看控件
            {
                    type:  'view',
                    labelWidth： '',// lable宽度
                    style: { color:'red' },// 自定义样式
                    labelText:  '用户名称',
                    fieldName:  'userName',
                    viewOptions: true, //处理编辑类型为(select/radio),view显示对应的label文本 配合optionUrl，options使用
                    optionUrl: {// 异步数据源
                        api: 'ProjectApply.getProjectSource', // 下拉数据源api
                        params: { dicType: 'TASK_SOURCE' }// 参数
                    },
                    options: [ // 自定义数据源优先级大于异步数据源
                       {
                           value:'value',
                           label:'label'
                       }
                    ],
                    formatter：(undefined,undefined,value,undefined)=>{// 格式化显示数据
                        // TODO
                        return ''
                    }    
             },
             // 附件查看控件
             {
                    type:  'uploadView',
                    labelWidth： '',// lable宽度
                    labelText:  '用户名称',
                    fieldName:  'userName',
                    filesLayout：'row' // row/card   
            }, 
            // link
             {
                    type:  'link',
                    labelWidth： '',// lable宽度
                    labelText:  '用户名称',
                    fieldName:  'userName',
                    callback: //点击回调方法
            },     
            {
                //文本输入框
                type:'text',
                labelText:'',
                fieldName:'',
                labelWidth:'',
                placeholder:'',
                fieldConfig: {// element-ui 对应组件options
        		}, 
                rules:[]
            },
            {
                //文本域
                type:'textarea',
                labelText:'',
                fieldName:'',
                labelWidth:'',
                placeholder:'',
                fieldConfig: {// element-ui 对应组件options
        		}, 
                rules:[]
            },
            {
                //下拉选择
                type:'select',
                labelText:'',
                fieldName:'',
                labelWidth:'',
                placeholder:'',
                fieldConfig: {// element-ui 对应组件options
        		}, 
                optionUrl: {// 异步数据源
                    api: 'ProjectApply.getProjectSource', // 下拉数据源api
                    params: { dicType: 'TASK_SOURCE' }// 参数
                },
                options: [ // 自定义数据源优先级大于异步数据源
                   {
                       value:'value',
                       label:'label'
                   }
                ],
                rules:[]
            },
            {
                //多选下拉选择
                type:'multiple',
                labelText:'',
                fieldName:'',
                labelWidth:'',
                placeholder:'',
                fieldConfig: {// element-ui 对应组件options
        		}, 
                optionUrl: {// 异步数据源
                    api: 'ProjectApply.getProjectSource', // 下拉数据源api
                    params: { dicType: 'TASK_SOURCE' }// 参数
                },
                options: [ // 自定义数据源优先级大于异步数据源
                   {
                       value:'value',
                       label:'label'
                   }
                ],
                rules:[]
            },
             // 上传控件
              {
                    type:  'upload',
                    labelText:  '用户名称',
                    fieldName:  'userName',
                    labelWidth:  '',// label宽度
                    colLayout:  'doubleCol',// 布局双列 ，单列为空
                    listType: '',//文件列表的类型	string	custom/secret(带密级选择)/text/picture/picture-card	
                    uploadConfig: {// element-ui 对应组件options

                    },     
                    rules: []
               },      
            // 树下拉选择
           {
                type:  'treeSelect',
                labelText:  '用户名称',
                fieldName:  'userName',
                placeholder:  '请输入用户名称',
                defaultExpandAll: true,// 默认展开全部
                multiple: true, // 多选
                disabled: true, // 禁止选择
                treeProps: {
                  value: 'value', // 树节点选中值
                  label: 'label', // 树节点显示值
                  children: 'children' // 子节点字段
                },
                checkStrictly: true, //在显示复选框的情况下，是否严格的遵循父子不互相关联的做法 默认true
                disabledMethod:,// 自定义树节点禁用方法 返回true禁用
                disabledAsynMethod:,// 自定义异步树节点禁用方法 返回promise对象 resolve(res)为节点id集合数组    
                clearable: true,// 清除按钮
                disabledValues: ['1'], // 设置禁用节点 节点id集合
                defaultExpandedKeys: ['1'], // 设置展开节点 节点id集合   
                colLayout:  'doubleCol',// 布局双列 ，单列为空
                tip: '用户名称输入要求：必须包含大写字母与下划线',// 仅对type='view'有效
                fieldConfig: {// element-ui 对应组件options
                    disabled: true
                },
                rules: [// 各种自定义类型   定义在 src/utils/extendValidate 中    持续添加中.......
                  {
                    required:  true,
                    message:  '必填'
                  }
                ]
          	},
             // Switch 开关
           {
                type:  'switch',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    // active-color:#13ce66  inactive-color:#ff4949
                    disabled: true
                },
                rules: []
           }, 
           // 普通单选组
           {
                type:  'radio',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    disabled: true
                },
                options: [//单选数据源 目前只支持自定义数据源
                    {
                        value:'value',
                        label:'label'
                    }
                ],
                rules: []
           }, 
           // 按钮单选组
           {
                type:  'radioButton',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    disabled: true
                },
                options: [//单选数据源 目前只支持自定义数据源
                    {
                        value:'value',
                        label:'label'
                    }
                ],
                rules: []
           }, 
           // 多选框 默认绑定变量的值会是Boolean，选中为true
           {
                type:  'checkbox',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    disabled: true
                },
                label: 'label',// 显示文字
                rules: []
           },
           // 多选框组 默认绑定变量的值会是Array，选中为数据源value集合
           {
                type:  'checkboxGroup',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    disabled: true
                },
                options: [//多选数据源 目前只支持自定义数据源
                    {
                        value:'value',
                        label:'label'
                    }
                ],
                rules: []
           },
           // 普通日期选择控件 type: 'date'
           {
                type:  'datetime',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    // valueFormat 绑定值格式需要自己定义 
                    // valueFormat: 'yyyy-MM-dd' 2020-01-01
                    // type: 'date'
                    disabled: true
                },
                rules: []
           },
           // 普通日期范围选择控件 type: 'daterange'
           {
                type:  'datetimeRange',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    // valueFormat 绑定值格式需要自己定义 
                    // valueFormat: 'yyyy-MM-dd' 2020-01-01
                    disabled: true
                },
                rules: []
           },     
        ]
   },     
   // 上传控件
  {
        type:  'upload',
        labelText:  '用户名称',
        fieldName:  'userName',
        labelWidth:  '',// label宽度
        colLayout:  'doubleCol',// 布局双列 ，单列为空
        listType: '',//文件列表的类型	string	custom/secret(带密级选择)/text/picture/picture-card	
        uploadConfig: {// element-ui 对应组件options
            
        },     
        rules: []
   },      
   // 文本输入框 默认最大120字符
  {
        type:  'text',
        labelText:  '用户名称',
        fieldName:  'userName',
        placeholder:  '请输入用户名称',
        colLayout:  'doubleCol',// 布局双列 ，单列为空
        tip: '用户名称输入要求：必须包含大写字母与下划线',// 仅对type='view'有效
      	fieldConfig: {// element-ui 对应组件options
            disabled: true
        },
        rules: [ // 各种自定义类型   定义在 src/utils/extendValidate 中    持续添加中.......
          {
            required:  true,
            message:  '必填'
          },
        ]
   }, 
   // 数字输入框
  {
        type:  'number',
        labelText:  '用户名称',
        fieldName:  'userName',
        placeholder:  '请输入用户名称',
        colLayout:  'doubleCol',// 布局双列 ，单列为空
        tip: '用户名称输入要求：必须包含大写字母与下划线',// 仅对type='view'有效
      	fieldConfig: {// element-ui 对应组件options
            disabled: true
        },
        minName: 'minName', // 对应P8Form中formData对象设置的最小值字段名称
        maxName: 'maxName', // 对应P8Form中formData对象设置的最大值字段名称
      	eventHandle:{// 下拉选择change事件
           change: 'changeName'// methods中自定义change方法
       	},
        rules: [// 各种自定义类型   定义在 src/utils/extendValidate 中    持续添加中.......
          {
            required:  true,
            message:  '必填'
          },
          {
            validator: (rule, value, callback) => {
              if (!value) {
                // callback 是提示的信息
                return  callback(new  Error('团队名不能为空'))
              } else {
                // 调用封装了的异步效验方法，
                this.$api['menu.list']().then(response  => {
                  if (response.result.errcode !== '0') {
                    console.log('效验失败')
                  } else {
                    if (response.body[0] === 0) {
                      console.log(response.body[0]) 
                      callback()
                    } else {
                      callback()
                    }
                  }
              })
            }
           },
           trigger:  'blur'}
          ]
   }, 
   // 文本域 默认最大500字符
   {
        type:  'textarea',
        labelText:  '用户名称',
        fieldName:  'userName',
        placeholder:  '请输入用户名称',
        colLayout:  'doubleCol',// 布局双列 ，单列为空
        tip: '用户名称输入要求：必须包含大写字母与下划线',// 仅对type='view'有效
       	fieldConfig: {// element-ui 对应组件options
            disabled: true
        },
        rules: [// 各种自定义类型   定义在 src/utils/extendValidate 中    持续添加中.......
          {
            required:  true,
            message:  '必填'
          },
          {
            validator: (rule, value, callback) => {
              if (!value) {
                // callback 是提示的信息
                return  callback(new  Error('团队名不能为空'))
              } else {
                // 调用封装了的异步效验方法，
                this.$api['menu.list']().then(response  => {
                  if (response.result.errcode !== '0') {
                    console.log('效验失败')
                  } else {
                    if (response.body[0] === 0) {
                      console.log(response.body[0]) 
                      callback()
                    } else {
                      callback()
                    }
                  }
              })
            }
           },
           trigger:  'blur'}
          ]
   },
   // 隐藏文本控件
   {
        type:  'hidden',
        fieldName:  'userName'
   },
   // Switch 开关
   {
        type:  'switch',
        fieldName:  'userName',
       	fieldConfig: {// element-ui 对应组件options
            // active-color:#13ce66  inactive-color:#ff4949
            disabled: true
        },
        rules: []
   }, 
   // 普通单选组
   {
        type:  'radio',
        fieldName:  'userName',
       	fieldConfig: {// element-ui 对应组件options
            disabled: true
        },
        options: [//单选数据源 目前只支持自定义数据源
            {
                value:'value',
                label:'label'
            }
        ],
        rules: []
   }, 
   // 按钮单选组
   {
        type:  'radioButton',
        fieldName:  'userName',
       	fieldConfig: {// element-ui 对应组件options
            disabled: true
        },
        options: [//单选数据源 目前只支持自定义数据源
            {
                value:'value',
                label:'label'
            }
        ],
       	rules: []
   }, 
   // 多选框 默认绑定变量的值会是Boolean，选中为true
   {
        type:  'checkbox',
        fieldName:  'userName',
       	fieldConfig: {// element-ui 对应组件options
            disabled: true
        },
        label: 'label',// 显示文字
        rules: []
   },
   // 多选框组 默认绑定变量的值会是Array，选中为数据源value集合
   {
        type:  'checkboxGroup',
        fieldName:  'userName',
       	fieldConfig: {// element-ui 对应组件options
            disabled: true
        },
        options: [//多选数据源 目前只支持自定义数据源
            {
                value:'value',
                label:'label'
            }
        ],
        rules: []
   },
   // 普通日期选择控件 type: 'date'
   {
        type:  'datetime',
        fieldName:  'userName',
       	fieldConfig: {// element-ui 对应组件options
            // valueFormat 绑定值格式需要自己定义 
            // valueFormat: 'yyyy-MM-dd' 2020-01-01
            // type: 'date'
            disabled: true
        },
        eventHandle:{// 下拉选择change事件
           change: 'changeName'// methods中自定义change方法
       	},
        rules: []
   },
   // 自定义类型日期选择控件 如 年份选择，月份选择 
   // year/month/date/dates/ week/datetime/datetimerange/ daterange/monthrange
   {
        type:  'datepicker',
        fieldName:  'userName',
       	fieldConfig: {// element-ui 对应组件options
            // valueFormat 绑定值格式需要自己定义 
            // valueFormat: 'yyyy-MM-dd' 2020-01-01
            type: '',//自定义类型 可选参数 year/month/date/dates/ week/datetime/datetimerange/ daterange/monthrange
            disabled: true
        },
        eventHandle:{// 下拉选择change事件
           change: 'changeName'// methods中自定义change方法
       	},
        rules: []
   }, 
   // 普通日期范围选择控件 type: 'daterange'
   {
        type:  'datetimeRange',
        fieldName:  'userName',
       	fieldConfig: {// element-ui 对应组件options
            // valueFormat 绑定值格式需要自己定义 
            // valueFormat: 'yyyy-MM-dd' 2020-01-01
            disabled: true
        },
        eventHandle:{// 下拉选择change事件
           change: 'changeName'// methods中自定义change方法
       	},
        rules: []
   }, 
   // 下拉选择
   {
        type:  'select',
        labelText:  '用户名称',
        fieldName:  'userName',
        placeholder:  '请输入用户名称',
        colLayout:  'doubleCol',// 布局双列 ，单列为空
        tip: '用户名称输入要求：必须包含大写字母与下划线',// 仅对type='view'有效
        optionUrl: {// 异步数据源
            api: 'ProjectApply.getProjectSource', // 下拉数据源api
            params: { dicType: 'TASK_SOURCE' }// 参数
        },
        options: [ // 自定义数据源优先级大于异步数据源
           {
               value:'value',
               label:'label'
           }
        ],
       	fieldConfig: {// element-ui 对应组件options
            disabled: true
        },
       	eventHandle:{// 下拉选择change事件
           change: 'changeName'// methods中自定义change方法
       	},
        rules: [// 各种自定义类型   定义在 src/utils/extendValidate 中    持续添加中.......
          {
            required:  true,
            message:  '必填'
          },
          {
            validator: (rule, value, callback) => {
              if (!value) {
                // callback 是提示的信息
                return  callback(new  Error('团队名不能为空'))
              } else {
                // 调用封装了的异步效验方法，
                this.$api['menu.list']().then(response  => {
                  if (response.result.errcode !== '0') {
                    console.log('效验失败')
                  } else {
                    if (response.body[0] === 0) {
                      console.log(response.body[0]) 
                      callback()
                    } else {
                      callback()
                    }
                  }
              })
            }
           },
           trigger:  'blur'}
          ]
   },
   // 多选下拉选择
   {
        type:  'multiple',
        labelText:  '用户名称',
        fieldName:  'userName',
        placeholder:  '请输入用户名称',
        colLayout:  'doubleCol',// 布局双列 ，单列为空
        tip: '用户名称输入要求：必须包含大写字母与下划线',// 仅对type='view'有效
        optionUrl: {// 异步数据源
            api: 'ProjectApply.getProjectSource', // 下拉数据源api
            params: { dicType: 'TASK_SOURCE' }// 参数
        },
        options: [ // 自定义数据源优先级大于异步数据源
           {
               value:'value',
               label:'label'
           }
        ],
       	fieldConfig: {// element-ui 对应组件options
            disabled: true
        },
       	eventHandle:{// 下拉选择change事件
           change: 'changeName'// methods中自定义change方法
       	},
        rules: [// 各种自定义类型   定义在 src/utils/extendValidate 中    持续添加中.......
          {
            required:  true,
            message:  '必填'
          },
          {
            validator: (rule, value, callback) => {
              if (!value) {
                // callback 是提示的信息
                return  callback(new  Error('团队名不能为空'))
              } else {
                // 调用封装了的异步效验方法，
                this.$api['menu.list']().then(response  => {
                  if (response.result.errcode !== '0') {
                    console.log('效验失败')
                  } else {
                    if (response.body[0] === 0) {
                      console.log(response.body[0]) 
                      callback()
                    } else {
                      callback()
                    }
                  }
              })
            }
           },
           trigger:  'blur'}
          ]
   },
   // 密级下拉选择
   {
        type:  'secretSelect',
        labelText:  '用户名称',
        fieldName:  'userName',
        placeholder:  '请输入用户名称',
        colLayout:  'doubleCol',// 布局双列 ，单列为空
        tip: '用户名称输入要求：必须包含大写字母与下划线',// 仅对type='view'有效
       	fieldConfig: {// element-ui 对应组件options
            disabled: true
        },
    	eventHandle:{// 下拉选择change事件
           change: 'changeName'// methods中自定义change方法
       	},
        rules: [// 各种自定义类型   定义在 src/utils/extendValidate 中    持续添加中.......
          {
            required:  true,
            message:  '必填'
          },
          {
            validator: (rule, value, callback) => {
              if (!value) {
                // callback 是提示的信息
                return  callback(new  Error('团队名不能为空'))
              } else {
                // 调用封装了的异步效验方法，
                this.$api['menu.list']().then(response  => {
                  if (response.result.errcode !== '0') {
                    console.log('效验失败')
                  } else {
                    if (response.body[0] === 0) {
                      console.log(response.body[0]) 
                      callback()
                    } else {
                      callback()
                    }
                  }
              })
            }
           },
           trigger:  'blur'}
          ]
   },
   // 树下拉选择
   {
        type:  'treeSelect',
        labelText:  '用户名称',
        fieldName:  'userName',
        placeholder:  '请输入用户名称',
        defaultExpandAll: true,// 默认展开全部
        multiple: true, // 多选
        disabled: true, // 禁止选择
        treeProps: {
          value: 'value', // 树节点选中值
          label: 'label', // 树节点显示值
          children: 'children' // 子节点字段
        },
        checkStrictly: true, //在显示复选框的情况下，是否严格的遵循父子不互相关联的做法 默认true
        disabledMethod:,// 自定义树节点禁用方法 返回true禁用
        disabledAsynMethod:,// 自定义异步树节点禁用方法 返回promise对象 resolve(res)为节点id集合数组    
        clearable: true,// 清除按钮
        disabledValues: ['1'], // 设置禁用节点 节点id集合
        defaultExpandedKeys: ['1'], // 设置展开节点 节点id集合   
        colLayout:  'doubleCol',// 布局双列 ，单列为空
        tip: '用户名称输入要求：必须包含大写字母与下划线',// 仅对type='view'有效
       	fieldConfig: {// element-ui 对应组件options
            disabled: true
        },
        rules: [// 各种自定义类型   定义在 src/utils/extendValidate 中    持续添加中.......
          {
            required:  true,
            message:  '必填'
          },
          {
            validator: (rule, value, callback) => {
              if (!value) {
                // callback 是提示的信息
                return  callback(new  Error('团队名不能为空'))
              } else {
                // 调用封装了的异步效验方法，
                this.$api['menu.list']().then(response  => {
                  if (response.result.errcode !== '0') {
                    console.log('效验失败')
                  } else {
                    if (response.body[0] === 0) {
                      console.log(response.body[0]) 
                      callback()
                    } else {
                      callback()
                    }
                  }
              })
            }
           },
           trigger:  'blur'}
          ]
   },    
]
```

使用`format`指定输入框的格式；使用`value-format`指定绑定值的格式。

默认情况下，组件接受并返回`Date`对象。以下为可用的格式化字串，以 UTC 2017年1月2日 03:04:05 为例：

请注意大小写

| 格式        | 含义             | 备注                                             | 举例          |
| :---------- | :--------------- | :----------------------------------------------- | :------------ |
| `yyyy`      | 年               |                                                  | 2017          |
| `M`         | 月               | 不补0                                            | 1             |
| `MM`        | 月               |                                                  | 01            |
| `W`         | 周               | 仅周选择器的 `format` 可用；不补0                | 1             |
| `WW`        | 周               | 仅周选择器的 `format` 可用                       | 01            |
| `d`         | 日               | 不补0                                            | 2             |
| `dd`        | 日               |                                                  | 02            |
| `H`         | 小时             | 24小时制；不补0                                  | 3             |
| `HH`        | 小时             | 24小时制                                         | 03            |
| `h`         | 小时             | 12小时制，须和 `A` 或 `a` 使用；不补0            | 3             |
| `hh`        | 小时             | 12小时制，须和 `A` 或 `a` 使用                   | 03            |
| `m`         | 分钟             | 不补0                                            | 4             |
| `mm`        | 分钟             |                                                  | 04            |
| `s`         | 秒               | 不补0                                            | 5             |
| `ss`        | 秒               |                                                  | 05            |
| `A`         | AM/PM            | 仅 `format` 可用，大写                           | AM            |
| `a`         | am/pm            | 仅 `format` 可用，小写                           | am            |
| `timestamp` | JS时间戳         | 仅 `value-format` 可用；组件绑定值为`number`类型 | 1483326245000 |
| `[MM]`      | 不需要格式化字符 | 使用方括号标识不需要格式化的字符 (如 [A] [MM])   | MM            |



- formData  隐藏域的值，增删行fieldName的声明，上传附件密级的声明，多选的声明

```js
formData:  Object.assign({}, {
	hiddenId:  '',
	checkboxGroup: [],
	detailList: [],
	confidentialiteList: []
})
```

existDefaultBtn与existCustomBtn
existDefaultBtn：是否显示表单自带的保存按钮，默认显示，与existCustomBtn对立
existCustomBtn：是否显示自定义的表单按钮，默认不显示，与existDefaultBtn对立
existDefaultBtn与existCustomBtn不能同时为false或同时为true

- secretLevelRules : 密级校验规则例子

  - 没有parentField字段为根密级
  - parentField存放需要限制小于某个密级的fieldName字段的值
  - fieldName对应dataSource中的fieldName或者formData中的存在的属性
  - name为提示文字

  [
  	{
  		name: '表单',
  		secretField: 'secretGrade',
  		fieldName: 'secretGrade',
  	},
  	{
  		parentField:'secretGrade',
  		name: '项目',
  		secretField: 'projectSecretGrade',
  		fieldName: 'projectSecretGrade',
  	},
  	{
  		parentField:'projectSecretGrade',
  		name: '任务',
  		secretField: 'taskSecretGrade',
  		fieldName: 'taskSecretGrade',
  	},
  	{
  		parentField:'secretGrade',
  		name: '表单附件'
  		secretField: 'confidentialite',
  		fieldName: 'getFile',
  	},
  ]

###### Options

| 属性             | 描述                                                        | 类型    | 默认值  |
| ---------------- | ----------------------------------------------------------- | ------- | ------- |
| comp             | this对象，配置表单事件                                      | Object  | {}      |
| form             | 表单数据对象                                                | Object  | {}      |
| dataSource       | 渲染表单的json                                              | Array   | []      |
| isCustomLogdate  | 保存时自否有自定义新旧值处理                                | Boolean | false   |
| isCustomValidate | 保存时自否有自定义校验                                      | Boolean | false   |
| labelWidth       | label宽度设置                                               | String  | '100px' |
| labelPosition    | label位置（支持el-form属性值）                              | String  | 'right' |
| api              | 表单保存api                                                 | String  | ''      |
| otherParam       | 表单保存自定参数                                            | Object  | {}      |
| existDefaultBtn  | 是否显示表单自带的保存按钮，默认显示，与existCustomBtn对立  | Boolean | true    |
| existCustomBtn   | 是否显示自定义的表单按钮，默认不显示，与existDefaultBtn对立 | Boolean | false   |
| openSecretLevel  | 开启密级校验                                                | Boolean | false   |
| secretLevelRules | 密级校验规则                                                | Array   | []      |



##### P8Search

![1619421125356](1619421125356.png)

统一要放置在north按钮区域

```vue
<p8-search ref="search"
           :form="form" // formModel 表单隐藏域的值或一些需要单独声明的值
           :dataSource="dataSource" // 查询表单json
           :labelWidth="labelWidth" // label的宽度
           :searchWidth="searchWidth" // 查询条件组件输入框的宽度
           :searchContainWidth="searchContainWidth" // 查询条件组件下拉内容的宽度
           :resetAfterToSearch="resetAfterToSearch" // 重置后是否再次查询
           @search="search" // 点击查询触发的方法
           @re-set="reSet"> // 点击重置触发的方法
                 
</p8-search>
```

- dataSource配置信息：(类似表单的dataSource)

```js
dataSource: [
    	// 普通下拉选择框
        {
          type: 'select',
          optionUrl: { // 自定义异步数据源
            api: 'thirdPartInterface.getDic',
            params: { dicType: 'EXECUTE_STATE' }
          },
          options: [ // 自定义数据源优先级大于异步
              {
                  value:'value',
                  label:'label'
              }
          ],
          labelText: '状态',
          fieldName: 'executeStates',
          placeholder: '选择状态',
          fieldConfig: {// element-ui 对应组件options
            disabled: true
          },
          rules: []// 各种自定义类型   定义在 src/utils/extendValidate 中   持续添加中.......  
        },
    	// 多选下拉选择框
        {
          type: 'multiple',
          optionUrl: { // 自定义异步数据源
            api: 'thirdPartInterface.getDic',
            params: { dicType: 'EXECUTE_STATE' }
          },
          options: [ // 自定义数据源优先级大于异步
              {
                  value:'value',
                  label:'label'
              }
          ],
          labelText: '状态',
          fieldName: 'executeStates',
          placeholder: '选择状态',
          fieldConfig: {// element-ui 对应组件options
            disabled: true
          },
          rules: []// 各种自定义类型   定义在 src/utils/extendValidate 中   持续添加中....... 
        },
    	// 文本输入框
        {
          type: 'text',
          labelText: '计划名称',
          fieldName: 'planName',
          placeholder: '请输入计划名称',
          fieldConfig: {// element-ui 对应组件options
            disabled: true
          },
          rules: []// 各种自定义类型   定义在 src/utils/extendValidate 中   持续添加中....... 
        },
    	// 文本域输入框
        {
          type: 'textarea',
          labelText: '计划名称',
          fieldName: 'planName',
          placeholder: '请输入计划名称',
          fieldConfig: {// element-ui 对应组件options
            disabled: true
          },
          rules: []// 各种自定义类型   定义在 src/utils/extendValidate 中   持续添加中.......   
        },
         // 数字输入框
        {
            type:  'number',
            labelText:  '用户名称',
            fieldName:  'userName',
            placeholder:  '请输入用户名称',
            fieldConfig: {// element-ui 对应组件options
                disabled: true
            },
            min: 'min', //最小值 默认最小为1
            max: 'max', //
            rules: [// 各种自定义类型   定义在 src/utils/extendValidate 中    持续添加中.......
                {
                    required:  true,
                    message:  '必填'
                },
                {
                    validator: (rule, value, callback) => {
                        if (!value) {
                            // callback 是提示的信息
                            return  callback(new  Error('团队名不能为空'))
                        } else {
                            // 调用封装了的异步效验方法，
                            this.$api['menu.list']().then(response  => {
                                if (response.result.errcode !== '0') {
                                    console.log('效验失败')
                                } else {
                                    if (response.body[0] === 0) {
                                        console.log(response.body[0]) 
                                        callback()
                                    } else {
                                        callback()
                                    }
                                }
                            })
                        }
                    },
                    trigger:  'blur'}
            ]
        }, 
        {
          type: 'datetimeRange',
          labelText: '创建日期',
          defaultValue: [],
          fieldName: 'recordingTime',
          placeholder: ['开始日期', '结束日期'],
          fieldConfig: {// element-ui 对应组件options
            disabled: true
          },
          rules: []// 各种自定义类型   定义在 src/utils/extendValidate 中   持续添加中.......   
        },
    	 // 树下拉选择
        {
            type:  'treeSelect',
            labelText:  '用户名称',
            fieldName:  'userName',
            placeholder:  '请输入用户名称',
            defaultExpandAll: true,// 默认展开全部
            multiple: true, // 多选
            disabled: true, // 禁止选择
            treeProps: {
                value: 'value', // 树节点选中值
                label: 'label', // 树节点显示值
                children: 'children' // 子节点字段
            },
            checkStrictly: true, //在显示复选框的情况下，是否严格的遵循父子不互相关联的做法 默认true
            disabledMethod:,// 自定义树节点禁用方法 返回true禁用
            disabledAsynMethod:,// 自定义异步树节点禁用方法 返回promise对象 resolve(res)为节点id集合数组    
            clearable: true,// 清除按钮
            disabledValues: ['1'], // 设置禁用节点 节点id集合
        	defaultExpandedKeys: ['1'], // 设置展开节点 节点id集合  
            fieldConfig: {// element-ui 对应组件options
                disabled: true
            },
            rules: []// 各种自定义类型   定义在 src/utils/extendValidate 中    持续添加中.......
    	},  
         // Switch 开关
           {
                type:  'switch',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    // active-color:#13ce66  inactive-color:#ff4949
                    disabled: true
                },
                rules: []
           }, 
           // 普通单选组
           {
                type:  'radio',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    disabled: true
                },
                options: [//单选数据源 目前只支持自定义数据源
                    {
                        value:'value',
                        label:'label'
                    }
                ],
                rules: []
           }, 
           // 按钮单选组
           {
                type:  'radioButton',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    disabled: true
                },
                options: [//单选数据源 目前只支持自定义数据源
                    {
                        value:'value',
                        label:'label'
                    }
                ],
                rules: []
           }, 
           // 多选框 默认绑定变量的值会是Boolean，选中为true
           {
                type:  'checkbox',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    disabled: true
                },
                label: 'label',// 显示文字
                rules: []
           },
           // 多选框组 默认绑定变量的值会是Array，选中为数据源value集合
           {
                type:  'checkboxGroup',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    disabled: true
                },
                options: [//多选数据源 目前只支持自定义数据源
                    {
                        value:'value',
                        label:'label'
                    }
                ],
                rules: []
           }, 
           // 普通日期选择控件 type: 'date'
           {
                type:  'datetime',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    // valueFormat 绑定值格式需要自己定义 
                    // valueFormat: 'yyyy-MM-dd' 2020-01-01
                    // type: 'date'
                    disabled: true
                },
                rules: []
           },
           // 自定义类型日期选择控件 如 年份选择，月份选择 
           // year/month/date/dates/ week/datetime/datetimerange/ daterange/monthrange
           {
                type:  'datepicker',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    // valueFormat 绑定值格式需要自己定义 
                    // valueFormat: 'yyyy-MM-dd' 2020-01-01
                    type: '',//自定义类型 可选参数 year/month/date/dates/ week/datetime/datetimerange/ daterange/monthrange
                    disabled: true
                },
                rules: []
           }, 
           // 普通日期范围选择控件 type: 'daterange'
           {
                type:  'datetimeRange',
                fieldName:  'userName',
                fieldConfig: {// element-ui 对应组件options
                    // valueFormat 绑定值格式需要自己定义 
                    // valueFormat: 'yyyy-MM-dd' 2020-01-01
                    disabled: true
                },
                rules: []
           },     
    ]
```

###### Options

| 属性               | 描述                             | 类型    | 默认值  |
| ------------------ | -------------------------------- | ------- | ------- |
| form               | 隐藏域的值或一些需要单独声明的值 | Object  | {}      |
| dataSource         | 渲染查询表单json                 | Object  | {}      |
| searchWidth        | 查询条件组件输入框的宽度         | String  | '450px' |
| searchContainWidth | 查询条件组件下拉内容的宽度       | String  | '450px' |
| labelWidth         | label宽度设置                    | String  | '90px'  |
| resetAfterToSearch | 重置后是否再次查询               | Boolean | false   |



##### P8FormGenerator

表单配置组件

###### Options

| 属性   | 描述 | 类型   | 默认值 |
| ------ | ---- | ------ | ------ |
| record |      | Object | {}     |



##### P8FormParser

表单编辑渲染组件

###### Options

| 属性      | 描述 | 类型   | 默认值 |
| --------- | ---- | ------ | ------ |
| formConf  |      | Object | {}     |
| modifyRes |      | Object | {}     |
| sysParams |      | Object | {}     |

##### P8FormParserView

表单查看渲染组件

###### Options

| 属性      | 描述 | 类型   | 默认值 |
| --------- | ---- | ------ | ------ |
| formConf  |      | Object | {}     |
| modifyRes |      | Object | {}     |
| sysParams |      | Object | {}     |
